$("#form").submit(function(e){
	e.preventDefault()

	var query = $("#search").val()

	var api_key = 'd113ef5b4f616d9c887099481622ee0a'

	let result = ''
	var  url = `http://api.serpstack.com/search?access_key=d113ef5b4f616d9c887099481622ee0a&query=${query}`

	$.get(url, function(data){

		data.organic_results.forEach(res =>{

			result = `
			<strong>${res.title}</strong><br><a target="_blank" href="${res.url}">${res.url}</a>
			<p>${res.snippet}</p>
			`
			$("#result").append(result)

		});
	});
});