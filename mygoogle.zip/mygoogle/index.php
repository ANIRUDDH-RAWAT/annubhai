<!DOCTYPE html>
<html>
<head>
	<title>My Search Engine</title>
	<meta charset="utf-8">
	<meta name="viewport"content="width=device-width,initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<style type="text/css">
		#annu{
			
			border-radius: 10%;
			margin-top: 10px;
		}
		#im{
			width: 7%;
			height: 5%;margin: 0 auto;
		}
	</style>
	
</head>
<body>
	<div class="container">
		<div id="im">
			<img src="img/annu.jpg" class="img-fluid" id="annu">
		</div>
		<h3 class="text-center"><strong class="text-danger">Annu</strong>&nbsp;<strong class="text-secondary">Bhai</strong>&nbsp;<strong class="text-success">Search</strong>&nbsp;<strong class="text-primary">Engine</strong>   </h3>
<form id="form" autocomplete="off">
	<div class="form-group">
		<input type="text" id="search" placeholder="search" autocomplete="off" class="form-control">
	</div>
	<div id="im">
		<button class="btn btn-danger">Search</button>
	</div>
	
</form>
<div id="result">
	
</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" src="js/index.js"></script>

</body>

</html>